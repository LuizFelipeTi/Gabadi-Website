<?php 
/*
Template Name: Recados
*/
?>


<?php get_header()?>
<link rel="stylesheet" type="text/css" href="<?=bloginfo('template_url')?>/arquivos/_css/recados.css" />


            <header id="fotos">


                <img class="image" src="<?=bloginfo('template_url')?>/arquivos/_imagens/fe.jpg" alt="rei"/>


            </header>

            

            
<?php get_footer(); ?>


