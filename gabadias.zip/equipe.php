<?php 
/*
Template Name: Equipe
*/
?>


<?php get_header()?>
<link rel="stylesheet" type="text/css" href="<?=bloginfo('template_url')?>/arquivos/_css/equipe.css" />


            <header id="fotos">


                <img class="image" src="<?=bloginfo('template_url')?>/arquivos/_imagens/fe.jpg" alt="rei"/>


            </header>


            
<?php get_footer(); ?>


