<form action="" mthod="get" accept-charset="utf-8" id="searchform" role="search">

    <div>
        <input type="text" name="s" value="pesquisar no site" onblur="if(this.value=='') this.value='Pesquisar no site';" 
        onfocus="if(this.value=='Pesquisar no site') this.value='';" />
        <input type="submit" id="searchsubmit" value="Buscar" />
    </div>

</form>