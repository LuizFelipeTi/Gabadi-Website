<div id="sidebar">
	<h2><?php _e('Categories'); ?></h2>
	<ul>
		<?php wp_list_cats('sort_column=name'); ?>
	</ul>
</div>	
